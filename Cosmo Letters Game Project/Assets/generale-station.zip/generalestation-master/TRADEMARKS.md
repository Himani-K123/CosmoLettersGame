Generale Station is a trademark of Ariel Martín Pérez (2020).
